
$( document ).ready(function() {	
	content ='';
	generalModule = localStorage.getItem("internationalization.general_module");
	videoId = localStorage.getItem("videoId");
	
	welcomeVideo = localStorage.getItem("internationalization.welcome_video")
	architectureVideo = localStorage.getItem("internationalization.architecture_video")
	frontendVideo = localStorage.getItem("internationalization.frontend_video");
	backendVideo = localStorage.getItem("internationalization.backend_video");
	databaseIndexes = localStorage.getItem("internationalization.database_indexes_video")
	internationalizationVideo = localStorage.getItem("internationalization.internationalization_video");
	scalabilityVideo = localStorage.getItem("internationalization.scalability_video");
	manutenabilityVideo = localStorage.getItem("internationalization.manutenability_video");
	content = "<h3 class='button text glass'>"+localStorage.getItem("internationalization.portfolio")+"</h3>";
	content += "<div>";
	content += "	<p class='text'></p>";
	content += "	<ul>";
	content += "		<li class='text "+ (videoId == welcomeVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+welcomeVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.welcome_3");
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == architectureVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+architectureVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.architecture");
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == frontendVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+frontendVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>Frontend";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == backendVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+backendVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>Backend";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == databaseIndexes ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+databaseIndexes+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.database_indexes")+"";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == internationalizationVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+internationalizationVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.internationalization")+"";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == scalabilityVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+scalabilityVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.scalability")+"";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == manutenabilityVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+manutenabilityVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.manutenability")+"";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == manutenabilityVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+manutenabilityVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.documentation")+"";
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == manutenabilityVideo ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+manutenabilityVideo+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.tests")+"";
	content += "		                        </a></li>";
	content += "	</ul>";
	content += "</div>";
	content += "<br><br>";
	content += "";
	
	continueCourseVideo = localStorage.getItem("internationalization.continue_course_video");
	continueCourseModule = localStorage.getItem("internationalization.continue_course_module");
	requirements = localStorage.getItem("internationalization.requirement_video");
	content += "<h3 class='button text glass'>"+localStorage.getItem("internationalization.free_course")+"</h3>";
	content += "<div>";
	content += "	<p class='text'>"+localStorage.getItem("internationalization.free_course_description")+"</p>";
	content += "	<ul>";
	content += "		<li class='text "+ (videoId == continueCourseVideo ? "selectedVideo" : "")+"'><a data-course='true'";
	content += "		                           data-video='"+continueCourseVideo+"'";
	content += "		                           data-module='"+continueCourseModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.continue_course");
	content += "		                        </a></li>";
	content += "		<li class='text "+ (videoId == requirements ? "selectedVideo" : "")+"'><a data-course='false'";
	content += "		                           data-video='"+requirements+"'";
	content += "		                           data-module='"+generalModule+"'";
	content += "		                           class='accordionClick'>"+localStorage.getItem("internationalization.requirement");
	content += "		                        </a></li>";
	content += "	</ul>";
	content += "</div>";
	content += "<br><br>";
	content += "";
	
	content += "<h3 class='button text glass'>Leonardo Da Vinci</h3>";
	content += "<div>";
	content += "	<p class='text'>"+localStorage.getItem("internationalization.simplicity")+"</p>";
	content += "	<ul>";
	content += "	</ul>";
	content += "</div>";
	content += "<br><br>";
	leftAccordionContent = content;
	localStorage.setItem("leftAccordionContent",  leftAccordionContent);
	
	$('#leftAccordion').append(leftAccordionContent);
	$("#leftAccordion").accordion();
	$("#leftAccordion" + selecionedMenu).click();	
	
	$.urlParam = function(name){
		var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
		if (results==null) {
		   return null;
		}
		return decodeURI(results[1]) || 0;
	}
	
	var content = ""
	var selecionedModule = ''
	var selecionedMenu = ''
	var courseId = localStorage.getItem("courseId")
	var videoId = localStorage.getItem("videoId")
	var moduleId = localStorage.getItem("moduleId")
	var screen = $.urlParam('screen')
	var token = localStorage.getItem("token")
	var tokenType = localStorage.getItem("tokenType")
	url = ''
	
	content = '';
	if(localStorage.getItem("isCourse") == 'true'){
		var accordionContent = localStorage.getItem("accordionContent");
			
			var modules = $.ajax({
			url: 'http://ec2-3-88-130-40.compute-1.amazonaws.com:8080/firewall/module/v1/retrieveByCourseIdWithVideos',
			//url: 'http://localhost:8080/firewall/module/v1/retrieveByCourseIdWithVideos',
			type: 'POST',
			contentType: 'application/json',
			data: JSON.stringify({
				courseId:localStorage.getItem("internationalization.course_id"),
				language:localStorage.getItem("language")
			}),
			dataType: 'json',
			success:function(modules) {
				
				var isCourse = localStorage.getItem("isCourse");
				
					for(i in modules){
						if(moduleId == modules[i].moduleId){
							content += "<h3 id='"+modules[i].number+"' class='button text glass selectedModule'>" + localStorage.getItem("internationalization.module") + " "+ modules[i].number + "</h3>";
							selecionedModule = modules[i].number;
						}else{
							content += "<h3 id='"+modules[i].number+"' class='button text glass'>" + localStorage.getItem("internationalization.module") + " "+ modules[i].number + "</h3>";
						}
						content += "<div>";
						content += "<p class='text moduleDescription'>" + modules[i].description + "</p>";
						content += "<ul>";
						for(j in modules[i].videos){
							if(videoId == modules[i].videos[j].videoId){
								content += "<li class='text selectedVideo'><a data-course='true' data-video='"+modules[i].videos[j].videoId+"' data-module='"+modules[i].moduleId+"' class='accordionClick' ";
							}else{
								content += "<li class='text'><a data-course='true' data-video='"+modules[i].videos[j].videoId+"' data-module='"+modules[i].moduleId+"' class='accordionClick' ";
							}
							content += "'>" + modules[i].videos[j].name + "</a></li>";
						}
						content += "</ul>";
						content += "<br/>";
						content += "</div>" + modules[i].name + "";
					}
					
				   $('#accordion').append(content);
				   $("#accordion").accordion();
					if(selecionedModule == ''){
						selecionedModule = 1;
					}
					$("#" + selecionedModule).click();
					
				},
				error: function (xhr) {
					var err = JSON.parse(xhr.responseText);
					if(xhr.status == 403){
					}
				}
			});
	}
	
	$.when(modules).done(function() {
			$('.accordionClick').click(function() {
				var videoId = $(this).data('video');
				var moduleId = $(this).data('module');
				var isCourse = $(this).data('course');
				localStorage.setItem("videoId",  videoId);
				localStorage.setItem("moduleId",  moduleId);
				localStorage.setItem("isCourse",  isCourse);
				window.location.href = "./video.html";
			});	

		});
		
		
	function internationalization() {
		$.ajax({
			url: 'http://ec2-3-88-130-40.compute-1.amazonaws.com:8080/firewall/internationalization/v1/frontend',
			//url: 'http://localhost:8080/firewall/internationalization/v1/frontend',
			async: false,  
			type: 'POST',
			contentType: 'application/json',
			data: JSON.stringify({
				locale:localStorage.getItem("language")
			}),
			dataType: 'json',
			success:function(internationalization) {
				for (let i = 0; i < internationalization.length; i++) {
				  let keyy = internationalization[i].keyy;
				  let message = internationalization[i].message;
				  localStorage.setItem('internationalization.'+keyy,  message);
				}
			},
			error: function (xhr) {
				if(xhr.responseText == undefined){
					alert('server offline');
				}else{
					alert(xhr.responseText);
				}
			}
		});
		localStorage.setItem("videoId",  localStorage.getItem("internationalization.welcome_video"));
		localStorage.setItem("moduleId",  localStorage.getItem("internationalization.general_module"));
		localStorage.setItem("isCourse",  'false');
		window.location.href = "./video.html";
	};
	
	$('#englishVersion, #usa').click(function() {
	  localStorage.setItem("language",  "en_US"); 
	  internationalization();
	});
	
	$('#portugueseVersion, #brazil').click(function() {
	  localStorage.setItem("language",  "pt_BR");
	  internationalization();
	});
		
	
});
